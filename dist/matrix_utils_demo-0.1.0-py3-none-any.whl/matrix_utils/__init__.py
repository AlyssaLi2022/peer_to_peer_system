# matrix_utils/__init__.py
# Expose functions from modules within this package
from .generator import generate_large_matrix

# Define package version
__version__ = "0.1.0"